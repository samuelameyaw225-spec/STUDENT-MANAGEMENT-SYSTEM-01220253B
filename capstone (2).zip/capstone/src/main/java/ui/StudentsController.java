package ui;

import domain.Student;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import repository.StudentRepositoryImpl;
import service.StudentService;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public class StudentsController {

    // --- Table Controls ---
    @FXML private TableView<Student> tableStudents;
    @FXML private TableColumn<Student, String> colId, colName, colProgramme, colStatus, colEmail;
    @FXML private TableColumn<Student, Integer> colLevel;
    @FXML private TableColumn<Student, Double> colGpa;
    @FXML private TableColumn<Student, String> phoneNumber, dateAdded;

    // --- Filter Controls ---
    @FXML private TextField txtSearch;
    @FXML private ComboBox<String> cmbFilterProgramme, cmbFilterStatus;
    @FXML private ComboBox<Integer> cmbFilterLevel;

    // --- Action Buttons ---
    @FXML private Button btnAdd, btnEdit, btnDelete, btnRefresh, btnSave, btnCancel;

    // --- Form Controls ---
    @FXML private VBox formPanel; // Wrap your form fields in a VBox in SceneBuilder
    @FXML private TextField txtId, txtName, txtProgramme, txtGpa, txtEmail, txtPhone;
    @FXML private ComboBox<Integer> cmbLevel;
    @FXML private ComboBox<String> cmbStatus;

    // --- Services and State ---
    private StudentService studentService;
    private ObservableList<Student> studentList;
    private FilteredList<Student> filteredData;
    private boolean isEditMode = false;

    @FXML
    public void initialize() {
        studentService = new StudentService(new StudentRepositoryImpl());

        // 1. Setup Form ComboBoxes
        ObservableList<Integer> levels = FXCollections.observableArrayList(100, 200, 300, 400, 500, 600, 700);
        cmbLevel.setItems(levels);
        cmbFilterLevel.setItems(levels);

        ObservableList<String> statuses = FXCollections.observableArrayList("Active", "Inactive");
        cmbStatus.setItems(statuses);
        cmbFilterStatus.setItems(FXCollections.observableArrayList("All", "Active", "Inactive"));
        cmbFilterProgramme.setItems(FXCollections.observableArrayList("All", "Computer Science", "Engineering", "Business", "Nursing"));

        // 2. Map Table Columns
        colId.setCellValueFactory(new PropertyValueFactory<>("studentId"));
        colName.setCellValueFactory(new PropertyValueFactory<>("fullName"));
        colProgramme.setCellValueFactory(new PropertyValueFactory<>("programme"));
        colLevel.setCellValueFactory(new PropertyValueFactory<>("level"));
        colGpa.setCellValueFactory(new PropertyValueFactory<>("gpa"));
        colEmail.setCellValueFactory(new PropertyValueFactory<>("email"));
        phoneNumber.setCellValueFactory(new PropertyValueFactory<>("phoneNumber"));
        dateAdded.setCellValueFactory(new PropertyValueFactory<>("dateAdded"));
        colStatus.setCellValueFactory(new PropertyValueFactory<>("status"));

        // 3. Load Data & Setup Listeners
        loadStudents();
        setupSearchAndFilter();
        setupTableSelection();

        // 4. Initial UI State
        setFormEnabled(false);
    }

    // --- DATA LOADING & FILTERING (Finished!) ---

    @FXML
    private void loadStudents() {
        try {
            List<Student> students = studentService.getAllStudents();
            studentList = FXCollections.observableArrayList(students);

            filteredData = new FilteredList<>(studentList, b -> true);
            SortedList<Student> sortedData = new SortedList<>(filteredData);
            sortedData.comparatorProperty().bind(tableStudents.comparatorProperty());

            tableStudents.setItems(sortedData);
        } catch (Exception e) {
            showAlert(Alert.AlertType.ERROR, "Database Error", "Failed to load students: " + e.getMessage());
        }
    }

    private void setupSearchAndFilter() {
        txtSearch.textProperty().addListener((obs, oldVal, newVal) -> applyFilters());
        cmbFilterProgramme.valueProperty().addListener((obs, oldVal, newVal) -> applyFilters());
        cmbFilterLevel.valueProperty().addListener((obs, oldVal, newVal) -> applyFilters());
        cmbFilterStatus.valueProperty().addListener((obs, oldVal, newVal) -> applyFilters());
    }

    private void applyFilters() {
        filteredData.setPredicate(student -> {
            String searchText = txtSearch.getText() != null ? txtSearch.getText().toLowerCase() : "";
            boolean matchesSearch = searchText.isEmpty() ||
                    student.getStudentId().toLowerCase().contains(searchText) ||
                    student.getFullName().toLowerCase().contains(searchText);

            String progFilter = cmbFilterProgramme.getValue();
            boolean matchesProg = progFilter == null || progFilter.equals("All") || student.getProgramme().equalsIgnoreCase(progFilter);

            Integer levelFilter = cmbFilterLevel.getValue();
            boolean matchesLevel = levelFilter == null || student.getLevel() == levelFilter;

            String statusFilter = cmbFilterStatus.getValue();
            boolean matchesStatus = statusFilter == null || statusFilter.equals("All") || student.getStatus().equalsIgnoreCase(statusFilter);

            return matchesSearch && matchesProg && matchesLevel && matchesStatus;
        });
    }

    // --- NEW: UI BEHAVIOR & BUTTON ACTIONS ---

    private void setupTableSelection() {
        // When a row is clicked, populate the form but keep it disabled until they click 'Edit'
        tableStudents.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                populateForm(newSelection);
                setFormEnabled(false);
            }
        });
    }

    @FXML
    private void handleRefresh() {
        loadStudents();
        clearForm();
        setFormEnabled(false);
        txtSearch.clear();
        cmbFilterProgramme.setValue("All");
        cmbFilterStatus.setValue("All");
        cmbFilterLevel.setValue(null);
    }

    @FXML
    private void handleAdd() {
        isEditMode = false;
        tableStudents.getSelectionModel().clearSelection();
        clearForm();
        setFormEnabled(true);
        txtId.setEditable(true); // You can type an ID when adding
    }

    @FXML
    private void handleEdit() {
        Student selected = tableStudents.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert(Alert.AlertType.WARNING, "No Selection", "Please select a student from the table to edit.");
            return;
        }
        isEditMode = true;
        setFormEnabled(true);
        txtId.setEditable(false); // Do not allow changing the primary key during edit!
    }

    @FXML
    private void handleDelete() {
        Student selected = tableStudents.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert(Alert.AlertType.WARNING, "No Selection", "Please select a student to delete.");
            return;
        }

        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Confirm Deletion");
        confirm.setHeaderText("Delete Student: " + selected.getFullName());
        confirm.setContentText("Are you sure you want to permanently delete this student?");

        Optional<ButtonType> result = confirm.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            try {
                studentService.deleteStudent(selected.getStudentId());
                loadStudents(); // Refresh table
                clearForm();
                showAlert(Alert.AlertType.INFORMATION, "Success", "Student deleted successfully.");
            } catch (Exception e) {
                showAlert(Alert.AlertType.ERROR, "Error", "Could not delete student: " + e.getMessage());
            }
        }
    }

    @FXML
    private void handleSave() {
        try {
            // Build student object from form
            Student student = new Student(
                    txtId.getText(), txtName.getText(), txtProgramme.getText(),
                    cmbLevel.getValue() != null ? cmbLevel.getValue() : 0,
                    Double.parseDouble(txtGpa.getText().isEmpty() ? "0.0" : txtGpa.getText()),
                    txtEmail.getText(), txtPhone.getText(),
                    LocalDate.now(), // Auto-assign today's date
                    cmbStatus.getValue() != null ? cmbStatus.getValue() : "Active"
            );

            if (isEditMode) {
                studentService.updateStudent(student);
                showAlert(Alert.AlertType.INFORMATION, "Success", "Student updated successfully!");
            } else {
                studentService.addStudent(student);
                showAlert(Alert.AlertType.INFORMATION, "Success", "Student added successfully!");
            }

            loadStudents(); // Refresh the table
            setFormEnabled(false);

        } catch (IllegalArgumentException e) {
            // Catches our strict validation rules from StudentService!
            showAlert(Alert.AlertType.WARNING, "Validation Error", e.getMessage());
        } catch (Exception e) {
            showAlert(Alert.AlertType.ERROR, "Save Error", "Could not save student: " + e.getMessage());
        }
    }

    @FXML
    private void handleCancel() {
        clearForm();
        setFormEnabled(false);
        tableStudents.getSelectionModel().clearSelection();
    }

    // --- UTILITY METHODS ---

    private void populateForm(Student student) {
        txtId.setText(student.getStudentId());
        txtName.setText(student.getFullName());
        txtProgramme.setText(student.getProgramme());
        txtGpa.setText(String.valueOf(student.getGpa()));
        txtEmail.setText(student.getEmail());
        txtPhone.setText(student.getPhoneNumber());
        cmbLevel.setValue(student.getLevel());
        cmbStatus.setValue(student.getStatus());
    }

    private void clearForm() {
        txtId.clear();
        txtName.clear();
        txtProgramme.clear();
        txtGpa.clear();
        txtEmail.clear();
        txtPhone.clear();
        cmbLevel.setValue(null);
        cmbStatus.setValue(null);
    }

    private void setFormEnabled(boolean enabled) {
        // Disables/Enables the fields so users don't type unless they hit Add or Edit
        txtId.setDisable(!enabled);
        txtName.setDisable(!enabled);
        txtProgramme.setDisable(!enabled);
        txtGpa.setDisable(!enabled);
        txtEmail.setDisable(!enabled);
        txtPhone.setDisable(!enabled);
        cmbLevel.setDisable(!enabled);
        cmbStatus.setDisable(!enabled);

        btnSave.setDisable(!enabled);
        btnCancel.setDisable(!enabled);
    }

    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    @FXML
    private void handleClearFilters() {
        txtSearch.clear();
        cmbFilterProgramme.setValue("All");
        cmbFilterStatus.setValue("All");
        cmbFilterLevel.setValue(null);

        if (filteredData != null) {
            filteredData.setPredicate(student -> true);
        }
    }

}