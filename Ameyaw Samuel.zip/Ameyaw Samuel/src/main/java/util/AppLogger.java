package util;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.logging.*;

public class AppLogger {

    private static final Logger logger = Logger.getLogger("StudentManagementSystem");

    static {
        try {
            // Ensure data folder exists
            Path dataDir = Path.of("data");
            if (!Files.exists(dataDir)) {
                Files.createDirectories(dataDir);
            }

            FileHandler fileHandler = new FileHandler("data/app.log", true);
            fileHandler.setFormatter(new SimpleFormatter());
            fileHandler.setLevel(Level.ALL);

            logger.addHandler(fileHandler);
            logger.setLevel(Level.ALL);

            // Disable console logging
            logger.setUseParentHandlers(false);

        } catch (IOException e) {
            System.err.println("Failed to initialize logging: " + e.getMessage());
        }
    }

    public static Logger getLogger() {
        return logger;
    }
}