package service;

import domain.Student;
import util.AppLogger;

import java.io.*;
import java.time.LocalDate;
import java.util.*;
import java.util.logging.Logger;

public class FileService {

    private static final String DATA_DIR = "data/";
    private static final Logger logger = AppLogger.getLogger();

    public FileService() {
        File dir = new File(DATA_DIR);
        if (!dir.exists()) {
            dir.mkdirs();
        }
    }

    // ===============================
    // EXPORT
    // ===============================

    public String exportToCSV(List<Student> students, String filename) {

        String filepath = DATA_DIR + filename + ".csv";

        try (PrintWriter writer = new PrintWriter(new FileWriter(filepath))) {

            writer.println("Student ID,Full Name,Programme,Level,GPA,Email,Phone,Date Added,Status");

            for (Student s : students) {
                writer.printf("%s,%s,%s,%d,%.2f,%s,%s,%s,%s\n",
                        s.getStudentId(), s.getFullName(), s.getProgramme(),
                        s.getLevel(), s.getGpa(), s.getEmail(),
                        s.getPhoneNumber(), s.getDateAdded().toString(), s.getStatus());
            }

            // LOG EXPORT COMPLETION (no personal data)
            logger.info("Export completed: " + filename + ".csv. Total records: " + students.size());

            return "Success! File exported to: " + filepath;

        } catch (IOException e) {

            logger.severe("Export failed for file: " + filename + ". Error: " + e.getMessage());

            return "Export failed: " + e.getMessage();
        }
    }

    // ===============================
    // IMPORT
    // ===============================

    public List<String> importFromCSV(File file, StudentService studentService) {

        List<String> importReport = new ArrayList<>();
        int successCount = 0;
        int errorCount = 0;

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {

            String line;
            boolean isFirstLine = true;
            int rowNumber = 1;

            while ((line = br.readLine()) != null) {

                if (isFirstLine) {
                    isFirstLine = false;
                    rowNumber++;
                    continue;
                }

                String[] data = line.split(",");

                try {

                    if (data.length < 9) {
                        throw new IllegalArgumentException(
                                "Missing columns. Expected 9, got " + data.length);
                    }

                    Student s = new Student(
                            data[0].trim(),
                            data[1].trim(),
                            data[2].trim(),
                            Integer.parseInt(data[3].trim()),
                            Double.parseDouble(data[4].trim()),
                            data[5].trim(),
                            data[6].trim(),
                            LocalDate.parse(data[7].trim()),
                            data[8].trim()
                    );

                    studentService.addStudent(s);
                    successCount++;

                } catch (Exception e) {

                    errorCount++;

                    String studentId = (data.length > 0) ? data[0] : "UNKNOWN";

                    importReport.add("Error on Row " + rowNumber +
                            " (ID: " + studentId + "): " + e.getMessage());
                }

                rowNumber++;
            }

            // LOG IMPORT SUMMARY (no personal data)
            logger.info("Import completed from file: " + file.getName() +
                    ". Success: " + successCount +
                    ", Errors: " + errorCount);

        } catch (Exception e) {

            logger.severe("CRITICAL import failure for file: " +
                    file.getName() + ". Error: " + e.getMessage());

            importReport.add("CRITICAL ERROR: Could not read file - " + e.getMessage());
        }

        importReport.add(0,
                "Import Complete! Successfully added " + successCount + " students.");

        return importReport;
    }
}