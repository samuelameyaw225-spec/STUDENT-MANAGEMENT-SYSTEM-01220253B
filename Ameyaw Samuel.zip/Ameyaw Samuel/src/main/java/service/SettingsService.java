package service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.prefs.Preferences;

public class SettingsService {

    // Preferences API creates a hidden, persistent file on the computer to save these values
    private final Preferences prefs = Preferences.userNodeForPackage(SettingsService.class);

    // Keys to look up our saved data
    private static final String THRESHOLD_KEY = "gpaThreshold";
    private static final String PROGRAMMES_KEY = "programmeList";

    // ================= GPA THRESHOLD =================

    public double getGpaThreshold() {
        // Fetches the saved threshold. If it hasn't been saved yet, it defaults to 2.0
        return prefs.getDouble(THRESHOLD_KEY, 2.0);
    }

    public void saveGpaThreshold(double threshold) {
        // Overwrites the old threshold with the new one
        prefs.putDouble(THRESHOLD_KEY, threshold);
    }

    // ================= PROGRAMMES =================

    public List<String> getProgrammes() {
        // Default list of programmes if the user hasn't added any yet
        String defaultProgs = "Computer Science,Engineering,Business,Nursing";

        // Fetch the saved comma-separated string
        String savedProgrammes = prefs.get(PROGRAMMES_KEY, defaultProgs);

        if (savedProgrammes.isEmpty()) {
            return new ArrayList<>();
        }

        // Convert the comma-separated string back into a Java List
        return new ArrayList<>(Arrays.asList(savedProgrammes.split(",")));
    }

    public void saveProgrammes(List<String> programmes) {
        // Convert the Java List into a single comma-separated string to save it
        String joined = String.join(",", programmes);
        prefs.put(PROGRAMMES_KEY, joined);
    }
}