package service;

import domain.Student;
import repository.IStudentRepository;
import util.AppLogger;

import java.util.Arrays;
import java.util.List;
import java.util.logging.Logger;

public class StudentService {

    private final IStudentRepository repository;
    private static final Logger logger = AppLogger.getLogger();

    public StudentService(IStudentRepository repository) {
        this.repository = repository;
    }

    public void addStudent(Student student) throws Exception {
        validateStudent(student);
        repository.addStudent(student);
        logger.info("Student added: " + student.getStudentId());
    }

    public void updateStudent(Student student) throws Exception {
        validateStudent(student);
        repository.updateStudent(student);
        logger.info("Student updated: " + student.getStudentId());
    }

    public void deleteStudent(String studentId) throws Exception {
        repository.deleteStudent(studentId);
        logger.info("Student deleted: " + studentId);
    }

    public List<Student> getAllStudents() throws Exception {
        return repository.getAllStudents();
    }

    public void validateStudent(Student student) {

        if (student.getStudentId() == null ||
                !student.getStudentId().matches("^[a-zA-Z0-9]{4,20}$")) {
            throw new IllegalArgumentException(
                    "Student ID must be 4 to 20 alphanumeric characters.");
        }

        if (student.getFullName() == null ||
                student.getFullName().length() < 2 ||
                student.getFullName().length() > 60 ||
                student.getFullName().matches(".*\\d.*")) {
            throw new IllegalArgumentException(
                    "Full name must be 2 to 60 characters and contain no numbers.");
        }

        if (student.getProgramme() == null ||
                student.getProgramme().trim().isEmpty()) {
            throw new IllegalArgumentException("Programme is required.");
        }

        List<Integer> validLevels =
                Arrays.asList(100, 200, 300, 400, 500, 600, 700);

        if (!validLevels.contains(student.getLevel())) {
            throw new IllegalArgumentException(
                    "Level must be one of: 100,200,300,400,500,600,700.");
        }

        if (student.getGpa() < 0.0 || student.getGpa() > 4.0) {
            throw new IllegalArgumentException(
                    "GPA must be between 0.0 and 4.0.");
        }

        if (student.getEmail() == null ||
                !student.getEmail().contains("@") ||
                !student.getEmail().contains(".")) {
            throw new IllegalArgumentException(
                    "Please enter a valid email address.");
        }

        if (student.getPhoneNumber() == null ||
                !student.getPhoneNumber().matches("^\\d{10,15}$")) {
            throw new IllegalArgumentException(
                    "Phone number must be 10 to 15 digits.");
        }
    }
}