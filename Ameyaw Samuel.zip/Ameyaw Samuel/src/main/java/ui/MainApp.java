package ui;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import util.DatabaseUtil;
import util.AppLogger;

import java.util.logging.Logger;

public class MainApp extends Application {

    private static final Logger logger = AppLogger.getLogger();

    @Override
    public void start(Stage primaryStage) throws Exception {

        // Initialize Database
        DatabaseUtil.initializeDatabase();
        logger.info("Application started and database initialized.");

        FXMLLoader loader = new FXMLLoader(getClass().getResource("/Main.fxml"));
        Parent root = loader.load();

        Scene scene = new Scene(root, 900, 600);
        scene.getStylesheets().add(
                getClass().getResource("/dashboard.css").toExternalForm()
        );

        primaryStage.setTitle("AMEYAW SAMUEL OPOKU");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    @Override
    public void stop() {
        logger.info("Application closed.");
    }

    public static void main(String[] args) {
        launch(args);
    }
}