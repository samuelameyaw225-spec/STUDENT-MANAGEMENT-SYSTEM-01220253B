package ui;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import service.SettingsService; // Make sure this import matches your package!

import java.util.ArrayList;

public class SettingsController {

    @FXML private TextField txtGpaThreshold;
    @FXML private TextField txtNewProgramme;
    @FXML private ListView<String> listProgrammes;

    private final ObservableList<String> programmeList = FXCollections.observableArrayList();

    // We only use the Service now! No more Preferences in this file.
    private final SettingsService settingsService = new SettingsService();

    @FXML
    public void initialize() {
        // Load data from the service when the screen opens
        loadThreshold();
        loadProgrammes();
        listProgrammes.setItems(programmeList);
    }

    // ================= GPA THRESHOLD =================

    private void loadThreshold() {
        // Fetch from service and display it
        double savedThreshold = settingsService.getGpaThreshold();
        txtGpaThreshold.setText(String.valueOf(savedThreshold));
    }

    @FXML
    private void handleSaveThreshold() {
        try {
            double threshold = Double.parseDouble(txtGpaThreshold.getText());

            if (threshold < 0.0 || threshold > 4.0) {
                showError("Threshold must be between 0.0 and 4.0.");
                return;
            }

            // Save via service
            settingsService.saveGpaThreshold(threshold);
            showInfo("Threshold updated successfully.");

        } catch (NumberFormatException e) {
            showError("Please enter a valid numeric GPA value.");
        }
    }

    // ================= PROGRAMME MANAGEMENT =================

    @FXML
    private void handleAddProgramme() {
        String newProgramme = txtNewProgramme.getText().trim();

        if (newProgramme.isEmpty()) {
            showError("Programme name cannot be empty.");
            return;
        }

        if (programmeList.contains(newProgramme)) {
            showError("Programme already exists.");
            return;
        }

        // Add to the UI list, then save the updated list via the service
        programmeList.add(newProgramme);
        saveProgrammes();

        txtNewProgramme.clear();
        showInfo("Programme added successfully.");
    }

    private void loadProgrammes() {
        // Fetch from service
        programmeList.setAll(settingsService.getProgrammes());
    }

    private void saveProgrammes() {
        // Save via service
        settingsService.saveProgrammes(new ArrayList<>(programmeList));
    }

    // ================= ALERT HELPERS =================

    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showInfo(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Success");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    @FXML
    private void handleDeleteProgramme() {
        // 1. Get the selected item from the ListView
        String selectedProgramme = listProgrammes.getSelectionModel().getSelectedItem();

        if (selectedProgramme == null) {
            showError("Please select a programme to delete.");
            return;
        }

        // 2. Remove it from the ObservableList (updates the UI instantly)
        programmeList.remove(selectedProgramme);

        // 3. Save the updated list to persistent storage
        saveProgrammes();

        showInfo("Programme deleted successfully.");
    }

}