package ui;

import domain.Student;
import javafx.animation.FadeTransition;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.chart.*;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.util.Duration;
import repository.StudentRepositoryImpl;
import service.FileService;
import service.ReportService;
import service.StudentService;

import java.util.List;
import java.util.Map;

public class ReportsController {

    // ================= TOP PERFORMERS =================
    @FXML private ComboBox<String> cmbTopProgramme;
    @FXML private ComboBox<Integer> cmbTopLevel;
    @FXML private TableView<Student> tableTop;
    @FXML private TableColumn<Student, String> colTopId, colTopName, colTopProg;
    @FXML private TableColumn<Student, Integer> colTopLevel;
    @FXML private TableColumn<Student, Double> colTopGpa;
    @FXML private BarChart<String, Number> barTopGpa;

    // ================= AT RISK =================
    @FXML private TextField txtRiskThreshold;
    @FXML private TableView<Student> tableRisk;
    @FXML private TableColumn<Student, String> colRiskId, colRiskName, colRiskProg;
    @FXML private TableColumn<Student, Integer> colRiskLevel;
    @FXML private TableColumn<Student, Double> colRiskGpa;
    @FXML private PieChart pieRiskDist;

    // ================= SUMMARY =================
    @FXML private ListView<String> listGpaDist;
    @FXML private ListView<String> listProgSummary;

    private ReportService reportService;
    private FileService fileService;

    @FXML
    public void initialize() {

        StudentService studentService = new StudentService(new StudentRepositoryImpl());
        reportService = new ReportService(studentService);
        fileService = new FileService();

        // Dropdowns
        cmbTopProgramme.setItems(FXCollections.observableArrayList(
                "All", "Computer Science", "Engineering", "Business", "Nursing"
        ));

        cmbTopLevel.setItems(FXCollections.observableArrayList(
                null, 100, 200, 300, 400, 500, 600, 700
        ));

        // Table Setup
        setupColumns(colTopId, colTopName, colTopProg, colTopLevel, colTopGpa);
        setupColumns(colRiskId, colRiskName, colRiskProg, colRiskLevel, colRiskGpa);

        // Initial Load
        loadTopPerformers();
        loadAtRiskStudents();
        loadSummaries();

        animateTable(tableTop);
        animateTable(tableRisk);
    }

    private void setupColumns(TableColumn<Student, String> id,
                              TableColumn<Student, String> name,
                              TableColumn<Student, String> prog,
                              TableColumn<Student, Integer> level,
                              TableColumn<Student, Double> gpa) {

        id.setCellValueFactory(new PropertyValueFactory<>("studentId"));
        name.setCellValueFactory(new PropertyValueFactory<>("fullName"));
        prog.setCellValueFactory(new PropertyValueFactory<>("programme"));
        level.setCellValueFactory(new PropertyValueFactory<>("level"));
        gpa.setCellValueFactory(new PropertyValueFactory<>("gpa"));
    }

    // ================= LOAD TOP =================
    @FXML
    private void loadTopPerformers() {
        try {
            String prog = cmbTopProgramme.getValue();
            Integer level = cmbTopLevel.getValue();

            List<Student> students = reportService.getTopPerformers(prog, level);
            tableTop.setItems(FXCollections.observableArrayList(students));

            updateTopChart(students);

        } catch (Exception e) {
            showAlert("Error", "Could not load top performers: " + e.getMessage());
        }
    }

    private void updateTopChart(List<Student> students) {

        barTopGpa.getData().clear();

        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.setName("GPA");

        for (Student s : students) {
            series.getData().add(
                    new XYChart.Data<>(s.getFullName(), s.getGpa())
            );
        }

        barTopGpa.getData().add(series);
    }

    // ================= LOAD AT RISK =================
    @FXML
    private void loadAtRiskStudents() {
        try {
            double threshold = Double.parseDouble(txtRiskThreshold.getText());
            List<Student> students = reportService.getAtRiskStudents(threshold);

            tableRisk.setItems(FXCollections.observableArrayList(students));
            updateRiskChart(students, threshold);

        } catch (NumberFormatException e) {
            showAlert("Input Error", "Threshold must be a valid number.");
        } catch (Exception e) {
            showAlert("Error", "Could not load at-risk students: " + e.getMessage());
        }
    }

    private void updateRiskChart(List<Student> riskStudents, double threshold) throws Exception{

        pieRiskDist.getData().clear();

        int riskCount = riskStudents.size();
        int total = reportService.getTotalStudents();
        int safeCount = total - riskCount;

        pieRiskDist.setData(FXCollections.observableArrayList(
                new PieChart.Data("At Risk (< " + threshold + ")", riskCount),
                new PieChart.Data("Safe Students", safeCount)
        ));
    }

    // ================= SUMMARY =================
    private void loadSummaries() {
        try {
            listGpaDist.getItems().clear();
            Map<String, Long> dist = reportService.getGpaDistribution();

            dist.forEach((band, count) ->
                    listGpaDist.getItems().add(band + ": " + count + " students")
            );

            listProgSummary.setItems(
                    FXCollections.observableArrayList(
                            reportService.getProgrammeSummary()
                    )
            );

        } catch (Exception e) {
            showAlert("Error", "Could not load summaries: " + e.getMessage());
        }
    }

    // ================= EXPORT =================
    @FXML
    private void exportTopPerformers() {
        String result = fileService.exportToCSV(
                tableTop.getItems(),
                "Top_Performers_Report"
        );
        showAlert("Export Status", result);
    }

    @FXML
    private void exportAtRiskStudents() {
        String result = fileService.exportToCSV(
                tableRisk.getItems(),
                "At_Risk_Report"
        );
        showAlert("Export Status", result);
    }

    // ================= UI ENHANCEMENTS =================
    private void animateTable(TableView<?> table) {
        FadeTransition fade = new FadeTransition(Duration.millis(700), table);
        fade.setFromValue(0);
        fade.setToValue(1);
        fade.play();
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}