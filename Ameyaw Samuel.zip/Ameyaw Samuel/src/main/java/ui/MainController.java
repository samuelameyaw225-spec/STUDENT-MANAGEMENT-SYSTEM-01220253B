package ui;

import domain.Student;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import service.StudentService;
import repository.StudentRepositoryImpl;

import java.io.IOException;
import java.util.List;


public class MainController {


    @FXML private Label lblTotalStudents;
    @FXML private Label lblActiveStudents;
    @FXML private Label lblInactiveStudents;
    @FXML private Label lblAvgGpa;


    @FXML private Button btnStudents;
    @FXML private Button btnReports;
    @FXML private Button btnImportExport;
    @FXML private Button btnSettings;
    @FXML private Button btnDashboard;

    private StudentService studentService;




    @FXML
    public void initialize() {

        studentService = new StudentService(new StudentRepositoryImpl());

        // Fill the labels with data from the database
        updateDashboardStats();


        //  BUTTON CLICKS (NAVIGATION)

        // 1. Link the Students button!
        btnStudents.setOnAction(e -> loadScreen("/Students.fxml"));

        // Placeholder for future screens
        btnReports.setOnAction(e -> System.out.println("Reports coming next..."));
        btnReports.setOnAction(e -> loadScreen("/Reports.fxml"));



        btnImportExport.setOnAction(e -> loadScreen("/ImportExport.fxml"));

        btnDashboard.setOnAction(e -> loadScreen("/Dashboard.fxml"));
        btnSettings.setOnAction(e -> loadScreen("/Settings.fxml"));





    }

    private void updateDashboardStats() {
        try {
            // Fetch all student records
            List<Student> students = studentService.getAllStudents();

            // 1. Total Students count
            int total = students.size();

            // 2. Active vs Inactive counts
            long active = students.stream()
                    .filter(s -> "Active".equalsIgnoreCase(s.getStatus()))
                    .count();
            long inactive = total - active;

            // 3. Average GPA calculation
            double avgGpa = students.stream()
                    .mapToDouble(Student::getGpa)
                    .average()
                    .orElse(0.0);

            // Update the UI labels
            lblTotalStudents.setText(String.valueOf(total));
            lblActiveStudents.setText(String.valueOf(active));
            lblInactiveStudents.setText(String.valueOf(inactive));
            lblAvgGpa.setText(String.format("%.2f", avgGpa));

        } catch (Exception e) {
            // If the database fails, show an error state
            lblTotalStudents.setText("Error");
            e.printStackTrace();
        }
    }



    //  NAVIGATION HELPER METHOD
    private void loadScreen(String fxmlPath) {
        try {
            // Load the new FXML screen
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlPath));
            Parent newScreen = loader.load();

            // Grab the main BorderPane layout from the current scene
            BorderPane mainLayout = (BorderPane) btnStudents.getScene().getRoot();

            // Swap the center content!
            mainLayout.setCenter(newScreen);

        } catch (IOException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Navigation Error");
            alert.setHeaderText("Could not load screen");
            alert.setContentText(e.getMessage());
            alert.showAndWait();
            e.printStackTrace();
        }
    }
}